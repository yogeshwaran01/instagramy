
 ## instagramy
  Get Instagram users informations
  
  ## Usage:
  from instagramy.instagram import Instagram <br /> <br />
  name = Instagram("virat.kohli") <br />
  popularity = name.popularity() <br />
  posts = name.get_posts_details() <br />
  profile = name.get_profile_pic() <br />
  bio = name.get_biography() <br />
  
  
